31-Mar-2009, filip.korc@uni-bonn.de
-----------------------------------

This is the eTRIMS Image Database v1. 

Please, see the accompanying technical report for details. If you make use of the database, 
we would appreciate if you cite the following reference in resulting publications:

@techreport{ korc-forstner-tr09-etrims,
             author = "Kor{\v c}, Filip and F{\" o}rstner, Wolfgang",
             title = "eTRIMS Image Database for Interpreting Images of Man-Made Scenes",
             number = "TR-IGG-P-2009-01",
             month = "March",
             year = "2009",
             institute = "Dept. of Photogrammetry, University of Bonn",
             url = "http://www.ipb.uni-bonn.de/projects/etrims_db/" }